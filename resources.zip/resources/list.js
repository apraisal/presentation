const auta = [
    { title: 'BMW', isAuto: true, id: 1 },
    { title: 'Audi', isAuto: true, id: 2 },
    { title: 'Romet', isAuto: false, id: 3 },
];